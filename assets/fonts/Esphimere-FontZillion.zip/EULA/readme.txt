Font Name : Esphimere
Created By Dichi!

This font is 100% free!
If you need help or have any suggestion, do not hesitate to e-mail me at diciganteng01@icloud.com
Also, please let me know if you want to use this font commercially.